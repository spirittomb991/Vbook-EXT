load("utils.js");

function execute(url, page) {
  var pageNo = 1;
  if (page !== null && page !== undefined && String(page) !== "") pageNo = parseInt(page, 10);
  if (!pageNo || pageNo < 1) pageNo = 1;

  var target = setPageParam(url, pageNo);

  var doc = getDoc(target);
  if (!doc) return Response.error("Không tải được thể loại");

  var list = parseComicList(doc);
  var next = null;
  if (list.length >= 18) next = String(pageNo + 1);
  return Response.success(list, next);
}
