const puppeteer = require('puppeteer');

async function execute(url) {
    // Nếu cần load config.js, hãy import lại cho phù hợp môi trường Node.js
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'networkidle2' });
    // Chờ các ảnh lazy load xuất hiện
    await page.waitForSelector('.lazy-image');
    // Lấy tất cả link ảnh đã load
    const imgs = await page.$$eval('.lazy-image', imgs => imgs.map(img => img.src));
    await browser.close();
    return Response.success(imgs);
}