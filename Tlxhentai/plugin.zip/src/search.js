load("utils.js");

function execute(key, page) {
    try {
        key = trimText(key);
        var url = BASE_URL + "/?s=" + encodeURIComponent(key);
        if (page && ("" + page).indexOf("http") === 0) url = page;
        Console.log("search url: " + url);
        var doc = getDoc(url);
        if (!doc) return Response.success([], null);
        var list = parseComicList(doc);
        var next = findNextPage(doc);
        Console.log("list count: " + list.length);
        return Response.success(list, next);
    } catch (e) {
        Console.log("search error: " + e);
        return Response.success([], null);
    }
}
