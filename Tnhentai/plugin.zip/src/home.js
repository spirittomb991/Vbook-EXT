function execute() {
    return Response.success([
        {title: "New uploads", input: "https://nhentai.website", script: "gen.js"}
    ]);
}