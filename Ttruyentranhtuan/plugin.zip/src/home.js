function execute() {
    return Response.success([
        {title: "Trang chủ", input: "http://truyentuan.xyz/", script: "gen.js"},

    ]);
}